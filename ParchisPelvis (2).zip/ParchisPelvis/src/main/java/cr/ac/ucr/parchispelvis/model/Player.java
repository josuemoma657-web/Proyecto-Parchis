/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.view.BoardView;

/**
 *
 * @author User
 */
public class Player {
    BoardView boardView;
    String name, color;
    int tokens, arrivedTokens;

    public Player(String name, String color) {
        this.color=color;
        this.name=name;
        boardView=new BoardView();
    }
    
    public void setVisiblePlayer(String color){
        switch(color){
            case "Orange":
                boardView.OrangePlayer();
                break;
            case "Blue":
                boardView.BluePlayer();
                break;
            case "Pink":
                boardView.PinkPlayer();
                break;
            case "Green":
                boardView.GreenPlayer();
                break;
        }
    }
    
}
