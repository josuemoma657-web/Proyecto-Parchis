/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.view.BoardView;
import cr.ac.ucr.parchispelvis.view.Window;

/**
 *
 * @author User
 */
public class Game {
    int times, turn; //si turn==0 turno del bot, turn==1 turno jugador
    String winner;
    Board board;
    Player player;
    BoardView boardView;
    Window window;

    public Game() {
        board=new Board();
        boardView=new BoardView();
        window=new Window();
        player=new Player(window.getName(), window.getColor());
    }
    
    public void turns(){
        winner="";
        turn=0;
        do{
        if(turn==1){
            boardView.CheckBtn(turn);
            player.setVisiblePlayer(window.getColor());
            //ejecuta todas las acciones del jugador
            turn=0; //turno bot
        }
        else{//ejecuta todas las acciones del bot
            turn=1; //turno jugador
        }
        }while(winner=="");
    }
    
    
}
