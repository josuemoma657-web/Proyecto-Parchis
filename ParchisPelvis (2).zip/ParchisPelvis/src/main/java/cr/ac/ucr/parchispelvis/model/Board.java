/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

/**
 *
 * @author User
 */
public class Board {
    int position, x, y;
    String move="moveY";
    String direction="-";
    
    Box boxes[];
    
    public void boxesArray(){
        for (int i = 0; i < boxes.length; i++) {
            boxes[i]=new Box("Normal", i+1);
        }
        
        
    }
    
    public void setTypes(int position){ //establece tipo de casilla
        for (int i = 0; i < boxes.length; i++) {
            switch(boxes[i].getPosition()){
                //Casillas especiales: 68, 63, 51, 46, 34, 29, 17, 12
                case 68:
                    boxes[i].setType("Special");
                    break;
                case 63:
                    boxes[i].setType("Special");
                    break;
                case 51:
                    boxes[i].setType("Special");
                    break;
                case 46:
                    boxes[i].setType("Special");
                    break;
                case 34:
                    boxes[i].setType("Special");
                    break;
                case 29:
                    boxes[i].setType("Special");
                    break;
                case 17:
                    boxes[i].setType("Special");
                    break;
                case 12:
                    boxes[i].setType("Special");
                    break;
            }
        }
    }
    
    
    
    public void tokenMovement(int position){ //direcciones y ejes, movimiento ficha
        x=370;
        y=600;
        
        for (int i = 0; i < boxes.length; i++) {
            switch(position){
                case 8:
                    move="moveX";
                    direction="+";
                    break;
                case 16:
                    move="moveY";
                    direction="-";
                    break;
                case 18:
                    move="moveX";
                    direction="-";
                    break;
                case 25:
                    move="moveY";
                    direction="-";
                    break;
                case 33:
                    move="moveX";
                    direction="-";
                    break;
                case 35:
                    move="moveY";
                    direction="+";
                    break;
                case 42:
                    move="moveX";
                    direction="-";
                    break;
                case 50:
                    move="moveY";
                    direction="+";
                    break;
                case 52:
                    move="moveX";
                    direction="+";
                    break;
                case 59:
                    move="moveY";
                    direction="+";
                    break;
                case 67:
                    move="moveX";
                    direction="+";
                    break;
            }
        }
    }
        
    public int getY() { //retorna Y
        for (int i = 0; i < boxes.length; i++) {
                if (move=="moveY"){
                    if (direction=="+"){
                        y=+30;
                    }
                    else{y=-30;}
                }
            }
        return y;
        }

    public int getX() { //retorna X
        for (int i = 0; i < boxes.length; i++) {
                if (move=="moveX"){
                    if (direction=="+"){
                        x=+30;
                    }
                    else{x=-30;}
                }
            }
        return x;
    }
        
  
    
}
