/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.model.Dice;
import cr.ac.ucr.parchispelvis.view.BoardView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class DiceCtrl implements ActionListener{

    BoardView boardView;
    Dice dice1;
    Dice dice2;
    String img1, img2;

    
    public DiceCtrl() {
        boardView=new BoardView();
        dice1=new Dice();
        dice2=new Dice();
        img1="";
        img2="";
    }    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
    }
    
    
    
}
