/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cr.ac.ucr.parchispelvis;

/**
 *
 * @author User
 */
public class ParchisPelvis {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
