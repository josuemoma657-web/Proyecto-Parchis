/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.model.QuestionBank;
import cr.ac.ucr.parchispelvis.view.QuestionW;
import cr.ac.ucr.parchispelvis.view.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */

public class QuestionCtrl implements ActionListener{

    private QuestionW qW;
    private Window window;
    private QuestionBank qb;
    private String type;
    private boolean correct, correctCheck;
    
    public QuestionCtrl(QuestionBank qb, String type) {
        System.out.println("Constructor de questionCtrl");
        this.qb=qb;
        qW=new QuestionW();
        qW.setController(this);
        this.type=type;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        switch(e.getActionCommand()){
            case"Verdadero":
                correct=checkBoxForQ(type);
                this.setCorrectCheck(qW.checkAnswer(false, correct));
                break;
            case"Falso":
                correct=checkBoxForQ(type);
                this.setCorrectCheck(qW.checkAnswer(false, correct));
                break;
        }
    }
    
    public boolean checkBoxForQ(String type){ //Revisa en que tipo de casilla está la ficha para lanzar pregunta
        this.setType(type);
        int num=0;
        num=qb.generateNumber();
        boolean check=false;
        switch(type){
            case"Normal":
                check=qW.setQuestion(qb.getEasyQuestion(num), qb.getAnswer1(num));
            break;
            case"Special":
                check=qW.setQuestion(qb.getHardQuestion(num), qb.getAnswer2(num));
                break;
        }
        return check;
    }

    
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isCorrectCheck() {
        return correctCheck;
    }

    public void setCorrectCheck(boolean correctCheck) {
        this.correctCheck = correctCheck;
    }
    
    
    
}
