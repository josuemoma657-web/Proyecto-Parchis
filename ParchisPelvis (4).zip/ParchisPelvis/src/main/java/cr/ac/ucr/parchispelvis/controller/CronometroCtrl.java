/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.model.Cronometro;
import cr.ac.ucr.parchispelvis.view.BoardView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class CronometroCtrl implements ActionListener{
    private Cronometro cronometro;
    private BoardView boardView;

    public CronometroCtrl(BoardView boardView) {
        this.boardView=boardView;
        boardView.setControllerCrono(this);
        this.cronometro=new Cronometro(boardView);
        this.cronometro.start();
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
        }
    }
}
