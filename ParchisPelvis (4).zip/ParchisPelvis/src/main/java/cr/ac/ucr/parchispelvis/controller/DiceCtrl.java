/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.model.Dice;
import cr.ac.ucr.parchispelvis.model.Game;
import cr.ac.ucr.parchispelvis.model.Token;
import cr.ac.ucr.parchispelvis.view.BoardView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class DiceCtrl implements ActionListener{

    private BoardView boardView;
    private Token token;
    private Game game;
    private Dice dice;
    
    public DiceCtrl(BoardView boardView, Game game){
        System.out.println("Constructor 1 de diceCtrl");
        dice=new Dice();
        game.getDiceIns(dice);
        this.boardView=boardView;
        this.game=game;
        this.boardView.setController(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case"Girar dado":
                dice.generateNumber();
                boardView.diceShow(dice.getNumber());
                game.turns();
            break;
        }
    }
    
    
    
    
}
