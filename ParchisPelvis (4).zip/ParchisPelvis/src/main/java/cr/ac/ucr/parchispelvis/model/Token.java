/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

/**
 *
 * @author User
 */
public class Token {
    private int status, position, goalPos;
    private String color, fMove, fDirection;
    private int x,y;
    private int winPos;
    
    public Token(String color) {
        System.out.println("Constructor de player");
        this.color = color;
        winPos=0;
        switch(color){ //recibe el color y establece las posiciones iniciales según cuál sea
            case"Orange":
                position=5;
                goalPos=68;
                fMove="moveY";
                fDirection="-";
                break;
            case "Blue":
                position=22;
                goalPos=17;
                fMove="moveX";
                fDirection="-";
                break;
            case "Pink":
                position=39;
                goalPos=34;
                fMove="moveY";
                fDirection="+";
                break;
            case "Green":
                position=56;
                goalPos=51;
                fMove="moveX";
                fDirection="+";
                break;
        }
    }
    
    public int getPosition() {
        return position;
    }
    
    public void setPosition(int position){
        this.position=position;
    }
    
    public boolean checkGoal(int position){
        if(position==goalPos){
            return true;
        }
        return false;
    }
    
    public String getFDirection(){
        return fDirection;
    }

    public String getfMove() {
        return fMove;
    }
    
    public int getY(int num) {
        for (int i = 0; i < num; i++) {
            if ("moveY".equals(fMove)){
                if ("+".equals(fDirection)){
                    y+=30;
                }
                else{y-=30;}
            }
            winPos++;
        }
        return y;
    }

    public int getX(int num) {
        for (int i = 0; i < num; i++) {
            if ("moveX".equals(fMove)){
                if ("+".equals(fDirection)){
                    x+=30;
                }
                else{x-=30;}
            }
            winPos++;
        }
        return x;
    }

    public void setFX(int x) {
        this.x = x;
    }

    public void setFY(int y) {
        this.y = y;
    }

    public int getGoalPos() {
        return goalPos;
    }
    
    public boolean checkWin(){
        if(winPos<=8){
            return true;
        }
        return false;
    }
    
}
