/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.view.BoardView;

/**
 *
 * @author User
 */
public class Cronometro extends Thread{
    private boolean corriendo=true;
    private int segundos=0;
    private BoardView boardView;

    public Cronometro(BoardView boardView) {
        this.boardView=boardView;
    }
    
    public void detener(){
        this.corriendo=false;
    }
    
    @Override
    public void run(){
        while(corriendo){
            try {
                this.sleep(1000);
                this.segundos++;
                boardView.setCronometro("Tiempo: "+segundos+" s");
            } catch (InterruptedException ex) {
                System.out.println("Se interrumpió el hilo");
            }
        }
    }
    
}
