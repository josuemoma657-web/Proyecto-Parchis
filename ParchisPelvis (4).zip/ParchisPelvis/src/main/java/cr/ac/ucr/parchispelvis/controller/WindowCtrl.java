/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.model.Game;
import cr.ac.ucr.parchispelvis.view.BoardView;
import cr.ac.ucr.parchispelvis.view.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class WindowCtrl implements ActionListener{
    
    private Window window;
    private String color, name, color1;
    private int numIn;
    private BoardView boardView;
    private Game game;
    
    public WindowCtrl(int j, Game game, String color1) {
        window=new Window(j);
        window.setController(this);
        color="";
        this.color1=color1;
        name="";
        numIn=j;
        this.game=game;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case"Naranja":
            color="Orange";
                break;
            case"Azul":
                color="Blue";
                break;
            case"Rosa":
                color="Pink";
                break;
            case"Verde":
                color="Green";
                break;
            case"Jugar":
            if(color1==color){
                JOptionPane.showMessageDialog(null, "Error, ¡Color ya elegido por jugador 1!");
            }
            name=window.playerName();
            if(color.equals("")){
                JOptionPane.showMessageDialog(null,"¡Color no elegido!");
            }
            if(name.equals("")){
                JOptionPane.showMessageDialog(null,"¡Olvidaste tu nombre!");
            }
            
            //verifica que se haya escrito un nombre, seleccionado color, y que no se repita entre j1 y j2
            if(!"".equals(name) && !color.equals("") &&color1!=color){ 
                game.registerPlayer(numIn, name, color);
                window.dispose();
                if (numIn==1) { //si el jugador es 1, ejecuta todo para jugador 2, al numIn ser 2 esto no se repite
                    new WindowCtrl(2, game, color); // crea jugador 2 después de cerrar jugador 1
                    //Y ejecuta la instancia de la clase actual con el color elegido como parámetro para verificar
                } else {
                game.turns(); // inicia el juego después de registrar jugador 2
                }
            }
            break;
        }
    }
    
    public String getName(){
        return name;
    }
    
    public String getColor(){
        return color;
    }
}
