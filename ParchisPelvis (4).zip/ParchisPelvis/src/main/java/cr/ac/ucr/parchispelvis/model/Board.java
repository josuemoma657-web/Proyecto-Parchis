/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

/**
 *
 * @author User
 */
public class Board {
    int position, x, y;
    String move;
    String direction;
    
    Box boxes[];

    public Board() {
        move="moveY";
        direction="-";
        boxes=new Box[68];
        this.boxesArray();
        System.out.println("Constructor de board");
    }
    
    
    public void boxesArray(){
        boxes[0]=new Box("Normal", 1);
        boxes[0].setX(370);
        boxes[0].setY(600);
        for (int i = 1; i < boxes.length; i++) {
            boxes[i]=new Box("Normal", i+1);
            this.setTypes(i);
            this.tokenMovement(i);
            this.setX(move, direction, i);
            this.setY(move, direction, i);
            boxes[i].setX(x);
            boxes[i].setY(y);
        }
    }
    
    public void setTypes(int i) { //establece tipo de casilla
        switch (i+1) {
            //Casillas especiales: 68, 63, 51, 46, 34, 29, 17, 12
            case 68:
                boxes[i].setType("Special");
                break;
            case 63:
                boxes[i].setType("Special");
                break;
            case 51:
                boxes[i].setType("Special");
                break;
            case 46:
                boxes[i].setType("Special");
                break;
            case 34:
                boxes[i].setType("Special");
                break;
            case 29:
                boxes[i].setType("Special");
                break;
            case 17:
                boxes[i].setType("Special");
                break;
            case 12:
                boxes[i].setType("Special");
                break;
        }
    }
    
    
    
    public void tokenMovement(int i){ //direcciones y ejes, movimiento ficha
            i++;
            if(i>=8 && i<16){
                move="moveX";
                direction="+";
            }
            if(i>=16 && i<18){
                move="moveY";
                direction="-";
            }
            if(i>=18 && i<25){
                move="moveX";
                direction="-";
            }
            if(i>=25 && i<33){
                move="moveY";
                direction="-";
            }
            if(i>=33 && i<35){
            move="moveX";
            direction="-";
            }
            if(i>=35 && i<42){
                move="moveY";
                direction="+";
            }
            if(i>=42 && i<50){
                move="moveX";
                direction="-";
            }
            if(i>=50 && i<52){
                move="moveY";
                direction="+";
            }
            if(i>=52 && i<59){
                move="moveX";
                direction="+";
            }
            if(i>=59 && i<67){
                move="moveY";
                direction="+";
            }
            if(i>=67 && i<68){
                move="moveX";
                direction="+";
        }
    }
        

    
    public int getPosition() {
        return position;
    }

    public String getDirection(int i) {
        return direction;
    }
    public String getAxis(int i){
        return move;
    }
        
    public void setY(String move, String direction, int i) {
        y=boxes[i-1].getY();
            if ("moveY".equals(move)){
                if ("+".equals(direction)){
                    y+=30;
                }
                else{y-=30;}
            }
    }

    public void setX(String move, String direction, int i) {
        x=boxes[i-1].getX();
            if ("moveX".equals(move)){
                if ("+".equals(direction)){
                    x+=30;
                }
                else{x-=30;}
            }
    }
    
    public String getBoxType(int i){
        return boxes[i].getType();
    }
    
    
    
}
