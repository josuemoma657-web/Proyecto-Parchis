/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.controller.DiceCtrl;
import cr.ac.ucr.parchispelvis.controller.QuestionCtrl;
import cr.ac.ucr.parchispelvis.controller.WindowCtrl;
import cr.ac.ucr.parchispelvis.view.BoardView;
import cr.ac.ucr.parchispelvis.view.Window;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Game {
    private int times, turn; //si turn==0 turno del bot, turn==1 turno jugador
    private String winner;
    private Board board;
    private Player player1;
    private Player player2;
    private BoardView boardView;
    private Window window;
    private QuestionCtrl qCtrl;
    private Dice dice;
    private DiceCtrl diceCtrl;
    private Token token1;
    private Token token2;
    private QuestionBank qb;
    private WindowCtrl windowCtrl;

    public Game() {
        turn=1;
        board=new Board();
        qb=new QuestionBank();
        windowCtrl=new WindowCtrl(1, this, null); //crea jugador 1 con la ventana que pide nombre y color
    }
    
    public void turns(){
        
        winner="";
        if(turn==1){ //ejecuta todas las acciones del jugador 1
            token1.setPosition(token1.getPosition()+dice.getNumber());
            if(token1.getPosition()>=68){
                token1.setPosition(token1.getPosition()-67);
            }
            boardView.setTurnText(player1.getName());
            boardView.setVisiblePlayer(player1.getColor()); 
            if(token1.checkGoal(token1.getPosition())){
                boardView.moveToken(player1.getColor(), token1.getX(dice.getNumber()), token1.getY(dice.getNumber()));
                if(token1.checkWin()){
                    winner=player1.getName();
                    JOptionPane.showMessageDialog(null, "Ganador: "+winner);
                }
            }
            else{boardView.moveToken(player1.getColor(), board.boxes[token1.getPosition()].getX(), board.boxes[token1.getPosition()].getY());
            }
            if(token1.getPosition()==token2.getPosition()) {
            System.out.println("¡Colisión! Se activa pregunta especial.");
            qCtrl = new QuestionCtrl(qb, "especial");
            } else {
                qCtrl=new QuestionCtrl(qb, board.getBoxType(token1.getPosition()-1)); //ejecuta controlador de pregunta}
                if(qCtrl.isCorrectCheck()){
                    player1.setPoints(player1.getPoints()+1);
                }
            }
            this.setTurn(2); //turno jugador 2
        }
        else{           //Ejecuta todas las acciones del jugador 2
            token2.setPosition(token2.getPosition()+dice.getNumber());
            if(token2.getPosition()>=68){
                token2.setPosition(token2.getPosition()-67);
            }
            boardView.setTurnText(player2.getName());
            boardView.setVisiblePlayer(player2.getColor());
            if(token1.checkGoal(token1.getPosition())){
                boardView.moveToken(player2.getColor(), token2.getX(dice.getNumber()), token2.getY(dice.getNumber()));
                if(token1.checkWin()){
                    winner=player2.getName();
                    JOptionPane.showMessageDialog(null, "Ganador: "+winner);
                }
            }
            else{boardView.moveToken(player2.getColor(), board.boxes[token2.getPosition()].getX(), board.boxes[token2.getPosition()].getY());
            }
            if(token1.getPosition()==token2.getPosition()){
            System.out.println("¡Colisión! Se activa pregunta especial.");
            qCtrl = new QuestionCtrl(qb, "especial");
            } else {
                qCtrl = new QuestionCtrl(qb, board.getBoxType(token2.getPosition()-1));
                if(qCtrl.isCorrectCheck()){
                    player2.setPoints(player2.getPoints()+1);
                }
            }
            this.setTurn(1); //turno jugador 1
        }
    }

    public int getTurn() {
        return turn;
    }

    public void setTurn(int turn) {
        this.turn = turn;
    }
    
    public void registerPlayer(int num, String nombre, String color) {
    if (num == 1) {
        player1 = new Player(nombre, color);
        token1 = new Token(color);
        token1.setFX(board.boxes[token1.getGoalPos()-1].getX());
        token1.setFY(board.boxes[token1.getGoalPos()-1].getY());
    } else {
        player2 = new Player(nombre, color);
        token2 = new Token(color);
        token2.setFX(board.boxes[token2.getGoalPos()-1].getX()); //establece las casillas por las que cada ficha se desvía
        token2.setFY(board.boxes[token2.getGoalPos()-1].getY());
        boardView=new BoardView(this);
    }
}

    public void checkCollision(){
        if(this.token1.getPosition()==token2.getPosition()){
        }
    }
    public void getDiceIns(Dice dice){
        this.dice=dice;
    }
    
    
}
