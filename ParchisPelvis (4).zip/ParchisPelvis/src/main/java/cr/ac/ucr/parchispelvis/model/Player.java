/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Player {
    private String name, color;
    private int tokens, points;

    public Player(String name, String color) {
        this.color=color;
        this.name=name;
        System.out.println("Constructor de player");
    }
        
    public String getColor() {
        return color;
    }
    
   public String getName(){
       return name;
   }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }
   
   
}
