/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cr.ac.ucr.parchispelvis;

import cr.ac.ucr.parchispelvis.model.Game;

/**
 *
 * @author User
 */
public class ParchisPelvis {

    public static void main(String[] args) {
        new Game();
    }
}
