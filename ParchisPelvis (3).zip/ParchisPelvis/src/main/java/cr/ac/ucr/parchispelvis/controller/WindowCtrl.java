/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.view.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class WindowCtrl implements ActionListener{
    
    Window window;
    String color, name;
    
    public WindowCtrl(int j) {
        window=new Window(j);
        color="";
        name="";
    }
    
    
    
    
    
   

    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case"Naranja":
            color="Orange";
                break;
            case"Azul":
                color="Blue";
                break;
            case"Rosa":
                color="Pink";
                break;
            case"Verde":
                color="Green";
                break;
            case"Jugar":
            if(color==""){
                JOptionPane.showMessageDialog(null,"¡Color no elegido!");
            }
            if(name==""){
                JOptionPane.showMessageDialog(null,"¡Olvidaste tu nombre!");
            }
            if(name!="" && color!=""){
                window.dispose();
            }
            break;
        }
    }
    
    public String getName(){
        return name;
    }
    
    public String getColor(){
        return color;
    }
}
