/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

/**
 *
 * @author User
 */
public class Board {
    int position, x, y;
    String move;
    String direction;
    
    Box boxes[];

    public Board() {
        move="moveY";
        direction="-";
        boxes=new Box[68];
    }
    
    
    public void boxesArray(){
        boxes[0]=new Box("Normal", 1);
        boxes[0].setX(370);
        boxes[0].setY(600);
        this.setTypes();
        this.tokenMovement();
        for (int i = 1; i < boxes.length; i++) {
            boxes[i]=new Box("Normal", i+1);
            this.setX(move, direction, i);
            this.setY(move, direction, i);
        }
    }
    
    public void setTypes(){ //establece tipo de casilla
        for (int i = 0; i < boxes.length; i++) {
            switch(boxes[i].getPosition()){
                //Casillas especiales: 68, 63, 51, 46, 34, 29, 17, 12
                case 68:
                    boxes[i].setType("Special");
                    break;
                case 63:
                    boxes[i].setType("Special");
                    break;
                case 51:
                    boxes[i].setType("Special");
                    break;
                case 46:
                    boxes[i].setType("Special");
                    break;
                case 34:
                    boxes[i].setType("Special");
                    break;
                case 29:
                    boxes[i].setType("Special");
                    break;
                case 17:
                    boxes[i].setType("Special");
                    break;
                case 12:
                    boxes[i].setType("Special");
                    break;
            }
        }
    }
    
    
    
    public void tokenMovement(){ //direcciones y ejes, movimiento ficha
        for (int i = 0; i < boxes.length; i++) {
            switch(i){
                case 8:
                    move="moveX";
                    direction="+";
                    break;
                case 16:
                    move="moveY";
                    direction="-";
                    break;
                case 18:
                    move="moveX";
                    direction="-";
                    break;
                case 25:
                    move="moveY";
                    direction="-";
                    break;
                case 33:
                    move="moveX";
                    direction="-";
                    break;
                case 35:
                    move="moveY";
                    direction="+";
                    break;
                case 42:
                    move="moveX";
                    direction="-";
                    break;
                case 50:
                    move="moveY";
                    direction="+";
                    break;
                case 52:
                    move="moveX";
                    direction="+";
                    break;
                case 59:
                    move="moveY";
                    direction="+";
                    break;
                case 67:
                    move="moveX";
                    direction="+";
                    break;
            }
        }
    }
        

    
    public int getPosition() {
        return position;
    }

    public String getDirection() {
        return direction;
    }
        
    public void setY(String move, String direction, int i) {
        y=boxes[i-1].getY();
            if (move=="moveY"){
                if (direction=="+"){
                    y=+30;
                }
                else{y=-30;}
            }
    }

    public void setX(String move, String direction, int i) {
        x=boxes[i-1].getX();
            if (move=="moveX"){
                if (direction=="+"){
                    x=+30;
                }
                else{x=-30;}
            }
    }
    
}
