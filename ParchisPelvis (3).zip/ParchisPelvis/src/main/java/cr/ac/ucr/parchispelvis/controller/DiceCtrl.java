/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.model.Dice;
import cr.ac.ucr.parchispelvis.model.Token;
import cr.ac.ucr.parchispelvis.view.BoardView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class DiceCtrl implements ActionListener{

    BoardView boardView;
    TokenCtrl tokenCtrl;
    Token token;
    
    public DiceCtrl(BoardView controller){
        this.boardView=controller;
    }

    public DiceCtrl(Token token) {
        this.token=token;
        boardView=new BoardView();
        tokenCtrl=new TokenCtrl();
        tokenCtrl.setMoved(false);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case"Girar dado":
            token.setBoxPosition(boardView.diceShow());
            boardView.setAllDiceFalse();
            tokenCtrl.setMoved(true);
            break;
        }
    }
    
    
    
    
}
