/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.view.BoardView;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Player {
    BoardView boardView;
    String name, color;
    int tokens, arrivedTokens;
    

    public Player(String name, String color) {
        this.color=color;
        this.name=name;
        boardView=new BoardView();
    }
    
    public void setPlayerColor(String color2){ //recibe el color que ya se eligió (para jugador 2)
        do{
            switch(color){
                case "Orange":
                    if(color2!="Orange"){
                        boardView.OrangePlayer();
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Error, ¡Color ya elegido por jugador 1!");
                    }
                    break;
                case "Blue":
                    if(color2!="Blue"){ //verifica que el color no haya sido elegido antes
                    boardView.BluePlayer();
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Error, ¡Color ya elegido por jugador 1!");
                    }
                    break;
                case "Pink":
                    if(color2!="Pink"){
                    boardView.PinkPlayer();
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Error, ¡Color ya elegido por jugador 1!");
                    }
                    break;
                case "Green":
                    if(color2!="Green"){
                    boardView.GreenPlayer();
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Error, ¡Color ya elegido por jugador 1!");
                    }
                    break;
            }
        }while(color=="");
    }

    
    public void setVisiblePlayer(){
        switch(color){
                case "Orange":
                        boardView.OrangePlayer();
                    break;
                case "Blue":
                    boardView.BluePlayer();
                    break;
                case "Pink":
                    boardView.PinkPlayer();
                    break;
                case "Green":
                    boardView.GreenPlayer();
                    break;
            }
    }
    
    public String getColor() {
        return color;
    }
    
   public String getName(){
       return name;
   }
}
