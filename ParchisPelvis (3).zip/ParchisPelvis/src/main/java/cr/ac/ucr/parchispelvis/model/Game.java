/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.controller.DiceCtrl;
import cr.ac.ucr.parchispelvis.controller.QuestionCtrl;
import cr.ac.ucr.parchispelvis.controller.WindowCtrl;
import cr.ac.ucr.parchispelvis.view.BoardView;
import cr.ac.ucr.parchispelvis.view.QuestionW;
import cr.ac.ucr.parchispelvis.view.Window;

/**
 *
 * @author User
 */
public class Game {
    int times, turn; //si turn==0 turno del bot, turn==1 turno jugador
    String winner;
    Board board;
    Player player1;
    Player player2;
    BoardView boardView;
    Window window;
    QuestionCtrl qCtrl;
    DiceCtrl diceCtrl;
    Token token1;
    Token token2;
    QuestionBank qb;
    WindowCtrl windowCtrl;

    public Game() {
        board=new Board();
        board.boxesArray();
        board.setTypes();
        qCtrl=new QuestionCtrl();
        windowCtrl=new WindowCtrl(1); //crea jugador 1 con la ventana que pide nombre y color
        player1=new Player(windowCtrl.getName(), windowCtrl.getColor());
        player1.setPlayerColor(""); 
        qCtrl=new QuestionCtrl();
        windowCtrl=new WindowCtrl(2); //crea jugador 2 con la ventana que pide nombre y color
        player2=new Player(windowCtrl.getName(), windowCtrl.getColor());
        player2.setPlayerColor(player1.getColor()); //recibe el color de jugador 1 para verificar que sea diferente
        token1=new Token(player1.getColor());
        token2=new Token(player2.getColor());
        boardView=new BoardView();
        this.turns();
        qb=new QuestionBank();
        
    }
    
    public void turns(){
        winner="";
        turn=1;
        do{
        if(turn==1){
            boardView.setTurnText(player1.getName());
            player1.setVisiblePlayer(); //ejecuta todas las acciones del jugador 1
            diceCtrl
            qb.checkBoxForQ(winner); //tira pregunta y comprueba respuesta
            turn=2; //turno jugador 2
        }
        else{//Ejecuta toas las acciones del jugador 2
            boardView.setTurnText(player2.getName());
            player2.setVisiblePlayer();
            turn=1; //turno jugador 1
        }
        }while(winner=="");
    }
    
    
}
