/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.view.BoardView;

/**
 *
 * @author User
 */
public class Token {
    int status, position;
    String color;
    Board board;
    BoardView boardView;
    
    public Token(String color) {
        this.color = color;
        switch(color){ //recibe el color y establece las posiciones iniciales según cuál sea
            case"Orange":
                position=5;
            case "Blue":
                position=22;
                break;
            case "Pink":
                position=39;
                break;
            case "Green":
                position=56;
                break;
        }
        board=new Board();
    }
    
    public void setBoxPosition(int position){ //actualiza la posición
        boardView.moveToken(color, board.boxes[position].getX(), board.boxes[position].getY());
    }

    public int getPosition() {
        return position;
    }
    
    
}
