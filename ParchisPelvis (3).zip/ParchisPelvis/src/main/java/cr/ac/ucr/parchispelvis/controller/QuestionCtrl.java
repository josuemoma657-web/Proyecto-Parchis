/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

import cr.ac.ucr.parchispelvis.view.QuestionW;
import cr.ac.ucr.parchispelvis.view.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */

public class QuestionCtrl implements ActionListener{

    QuestionW questionW;
    Window window;

    public QuestionCtrl() {
        questionW=new QuestionW();
        questionW.setController(this);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        switch(e.getActionCommand()){
            case"Verdadero":
                questionW.checkAnswer(true);
                break;
            case"Falso":
                questionW.checkAnswer(false);
                break;
        }
    }
    
    
}
