/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

import cr.ac.ucr.parchispelvis.view.QuestionW;

/**
 *
 * @author User
 */
public class QuestionBank {
    String questions[];
    boolean answer[];
    
    QuestionW qW;
    String questions2[];
    boolean answer2[];

    public QuestionBank() {
        qW=new QuestionW();
        this.easyQuestionfill();
        this.hardQuestionfill();
    }
    
    
    
    public void easyQuestionfill(){ 
        questions=new String[15];
        answer=new boolean[15];
        
        questions[0]="En los videojuegos, un \"NPC\" significa \"Non-Playable Character\" o personaje no jugable.";
        answer[0]=true;
        questions[1]="Java es un lenguaje de programación orientado a objetos.";
        answer[1]=true;
        questions[2]="El diseño visual solo se refiere a la estética y no a la funcionalidad.";
        answer[2]=true;
        questions[3]="HTML es un lenguaje de programación.";
        answer[3]=false;
        questions[4]="Un \"bug\" en programación es un error o fallo en el código.";
        answer[4]=true;
        questions[5]="En videojuegos, \"FPS\" significa \"Frames Per Second\" o cuadros por segundo.";
        answer[5]=true;
        questions[6]="CSS se utiliza para dar estilo a las páginas web.";
        answer[6]=true;
        questions[7]="El lenguaje Python es más difícil de aprender que Java.";
        answer[7]=false;
        questions[8]="En diseño visual, la tipografía no afecta la legibilidad.";
        answer[8]=false;
        questions[9]="Un \"sprite\" en videojuegos es una imagen o gráfico 2D.";
        answer[9]=true;
        questions[10]="JavaScript y Java son el mismo lenguaje.";
        answer[10]=false;
        questions[11]="En programación, un \"array\" es una estructura que almacena múltiples valores.";
        answer[11]=true;
        questions[12]="Los videojuegos siempre requieren conexión a internet para jugar.";
        answer[12]=false;
        questions[13]="El diseño visual incluye el uso del color, la forma y el espacio.";
        answer[13]=true;
        questions[14]="En programación, \"debuggear\" significa encontrar y corregir errores.";
        answer[14]=true;
    }
    
    public void hardQuestionfill(){
        questions2=new String[15];
        answer2=new boolean[15];
        
        questions2[0]="En los videojuegos, el término \"hitbox\" se refiere al área donde un personaje puede recibir daño.";
        answer2[0]=true;
        questions2[1]="Java es un lenguaje de programación que se ejecuta directamente en el hardware sin necesidad de una máquina virtual. ";
        answer2[1]=true;
        questions2[2]="En videojuegos, un \"Easter Egg\" es un contenido oculto que los jugadores pueden descubrir.";
        answer2[2]=true;
        questions2[3]="La encapsulación en programación orientada a objetos significa ocultar los detalles internos de una clase.";
        answer2[3]=true;
        questions2[4]="El protocolo FTP es más seguro que HTTPS para transferir archivos.";
        answer2[4]=false;
        questions2[5]="La herencia utiliza la palabra reservada \"extends\".";
        answer2[5]=true;
        questions2[6]="En NetBeans podemos crear interfaces de forma manual, o simplificada.";
        answer2[6]=true;
        questions2[7]="En java utilizamos el switch para repetir acciones.";
        answer2[7]=false;
        questions2[8]="Las condicionales de java sólo funcionan con variables numéricas.";
        answer2[8]=false;
        questions2[9]="El tipo de variable \"String\" es una cadena de datos \"char\".";
        answer2[9]=true;
        questions2[10]="El método MVC se divide en 4 partes.";
        answer2[10]=false;
        questions2[11]="Un arreglo puede ser de cualquier tipo de valores.";
        answer2[11]=true;
        questions2[12]="En diseño visual, el contraste no afecta la legibilidad del texto.";
        answer2[12]=false;
        questions2[13]="Para tener un número aleatorio, utilizamos la clase Math.";
        answer2[13]=true;
        questions2[14]="Existe más de una forma de crear instancias.";
        answer2[14]=true;
    }
    
    public int generateNumber(){
        return (int) (Math.random()*14+1);
    }
    
    public boolean checkBoxForQ(String type){
        int num;
        boolean check=false;
        switch(type){
            case"Normal":
                num=this.generateNumber();
                check=qW.checkAnswer(qW.setQuestion(this.getEasyQuestion(num), this.getAnswer1(num)));
            break;
            case"Special":
                num=this.generateNumber();
                check=qW.checkAnswer(qW.setQuestion(this.getHardQuestion(num), this.getAnswer1(num)));
                break;
        }
        return check;
    }
    
    public String getEasyQuestion(int num){
        return questions[num];
    }
    
    public String getHardQuestion(int num){
        return questions2[num];
    }
    
    public boolean getAnswer1(int num){
        return answer[num];
    }
}
