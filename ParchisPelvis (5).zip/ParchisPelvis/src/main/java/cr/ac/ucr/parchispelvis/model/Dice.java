/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.model;

/**
 *
 * @author User
 */
public class Dice {
    private int num;
    
    public void generateNumber(){
        num=(int) (Math.random()*6+1);
    }
    
    public int getNumber(){
        return num;
    }
}
