/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.parchispelvis.controller;

/**
 *
 * @author User
 */
public class TokenCtrl {
    private boolean moved;

    public TokenCtrl() {
    }

    
    
    
    
}
